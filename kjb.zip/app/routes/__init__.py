"""Route blueprints for API and views."""
